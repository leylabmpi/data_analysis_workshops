#!/bin/sh
# Add cluster information here (if needed)


# - - - - - - - - - - - - - - - - - - - - -
# @ Thomas W. Battaglia
# Workflow for processing fastq files from
# 16s rRNA sequencing into an OTU table in
# .biom format. This workflow assumes the
# data has a forward/reverse and index from
# an Illumina Miseq run.
# - - - - - - - - - - - - - - - - - - - - -

# Load MacQIIME 1.9.1
# or other QIIME 1.9.1 module
macqiime


# - - - - - - - - - - - - - - - - - - - - -
# Make directories to store the data
# - - - - - - - - - - - - - - - - - - - - -
mkdir -p pick_otus
mkdir -p pick_otus/chimeraslayer
mkdir -p results


# - - - - - - - - - - - - - - - - - - - - -
# Pick OTU's Workflow
# - - - - - - - - - - - - - - - - - - - - -
pick_open_reference_otus.py \
-i split_libraries/seqs.fna \
-o pick_otus \
-p 16s_pickotu_param.txt \
--parallel \
-aO 2
echo "Picking open-reference otu's...completed."


# - - - - - - - - - - - - - - - - - - - - -
# Remove Chimeric Sequences
# You must have ChimeraSlayer + BLAST
# installed!
# - - - - - - - - - - - - - - - - - - - - -

# Identify Chimerica sequences
parallel_identify_chimeric_seqs.py \
-m ChimeraSlayer \
-i pick_otus/pynast_aligned_seqs/rep_set_aligned.fasta \
-o pick_otus/chimeraslayer/chimeric_seqs.txt \
-O 2
echo "Identifying chimeric sequences...completed."

# Filter low reads from fasta file + chimeria sequences
filter_fasta.py \
-f pick_otus/pynast_aligned_seqs/rep_set_aligned.fasta \
-o pick_otus/chimeraslayer/rep_set_aligned_chimerafree.fasta \
-s pick_otus/chimeraslayer/chimeric_seqs.txt \
-n
echo "Filtering fasta sequences...completed."

# Filter Alignment
filter_alignment.py \
-i pick_otus/chimeraslayer/rep_set_aligned_chimerafree.fasta \
-o pick_otus/chimeraslayer
echo "Filtering alignment...completed."

# Make Phylogeny Tree
make_phylogeny.py \
-i pick_otus/chimeraslayer/rep_set_aligned_chimerafree_pfiltered.fasta \
-o pick_otus/chimeraslayer/rep_set_chimerafree.tre
echo "Making phylogenetic tree...completed."

# Make OTU Table (if pick open otu's paramters for least number of observations needed, you must change the input)
make_otu_table.py \
-i pick_otus/final_otu_map_mc2.txt \
-o results/otu_table_rdp_nochimera.biom \
-t pick_otus/rdp_assigned_taxonomy/rep_set_tax_assignments.txt \
-e pick_otus/chimeraslayer/chimeric_seqs.txt
echo "Making OTU table...completed."


# - - - - - - - - - - - - - - - - - - - - -
# Summarize OTU table for sample depths and
# final processing steps
# - - - - - - - - - - - - - - - - - - - - -

# Move important files to results folder
cp pick_otus/chimeraslayer/otu_table_rdp_nochimera.biom results/
cp pick_otus/chimeraslayer/rep_set_chimerafree.tre results/
cp pick_otus/chimeraslayer/rep_set_aligned_chimerafree.fasta results/
cp mapping_file.txt results/

# Retrieve sequence/otu counts per sample.
biom summarize-table \
-i results/otu_table_rdp_nochimera.biom \
-o results/otu_table_rdp_nochimera_results.txt

