Moving Pictures of the Human Microbiome
Caporaso JG, Lauber CL, Costello EK, Berg-Lyons D, Gonzalez A, Stombaugh J, Knights D, Gajer P, Ravel J, Fierer N, Gordon JI, Knight R
Genome Biol. 2011 May 30;12(5):R50.
